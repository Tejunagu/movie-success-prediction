# -*- coding: utf-8 -*-
"""
Created on Fri Mar  3 19:18:46 2023

@author: S.Ramya
"""

from flask import Flask,render_template,request
import os
import pickle
import numpy as np
app=Flask(__name__)
@app.route('/',methods=["GET","POST"])    
def index():
    return render_template('index.html')
@app.route("/predict",methods=["POST"])
def predict():
    gross=float(request.form["gross"])
    fblikes=float(request.form["fblikes"])
    movie_name = request.form["movie_name"]
    print("fblikes:",fblikes)
    print("gross:",gross)
    cur_dir=os.path.dirname(__file__)
    k_Neighbors_model=pickle.load(open(os.path.join(cur_dir,'pickle_files/k_Neighbors_regressor_model.sav'),'rb'))
    ip_arr = np.array([[fblikes,gross]])
    
   #list1=[James Cameron,Gore Verbinski	,Sam Mendes	,Christopher Nolan,Andrew Stanton,Scott Smith,Benjamin Roberds,Daniel Hsia,Jon Gunn	]
    #l1=list[]
    
    #pred=clf.predict(ip_arr)
    k_pred=k_Neighbors_model.predict(ip_arr)
    print("Prediction : ", k_pred)
    
    if ((k_pred) >=7.9):
        result="Super Hit"
    elif(((k_pred) >5) & ((k_pred)<8)):
        result=" Hit"
    else:
        result="Flop"   
    
    #print("Prediction:" , pred)
    return render_template('result.html', result=result, movie_name=movie_name)
if __name__== '__main__':
    app.run()

